#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
import json
from sdwan import *
from sdwan_utils.utils import *
from myXLS import *
def createVPNPayload(templateName, vpn_id, templateDescription=None):
    return json.dumps(\
    {'deviceType': ['vedge-cloud'],
     'factoryDefault': False,
     'templateDefinition': {'ecmp-hash-key': {'layer4': {'vipObjectType': 'object',
                                                         'vipType': 'ignore',
                                                         'vipValue': 'false',
                                                         'vipVariableName': 'vpn_layer4'}},
                            'host': {'vipObjectType': 'tree',
                                     'vipPrimaryKey': ['hostname'],
                                     'vipType': 'ignore',
                                     'vipValue': []},
                            'ip': {'gre-route': {},
                                   'ipsec-route': {},
                                   'service-route': {}},
                            'ipv6': {},
                            'name': {'vipObjectType': 'object',
                                     'vipType': 'constant',
                                     'vipValue': 'Branch_VPN_300_Template',
                                     'vipVariableName': 'vpn_name'},
                            'nat64': {'v4': {'pool': {'vipObjectType': 'tree',
                                                      'vipPrimaryKey': ['name'],
                                                      'vipType': 'ignore',
                                                      'vipValue': []}}},
                            'nat64-global': {'prefix': {'stateful': {}}},
                            'omp': {'advertise': {'vipObjectType': 'tree',
                                                  'vipPrimaryKey': ['protocol'],
                                                  'vipType': 'ignore',
                                                  'vipValue': []},
                                    'distance': {'vipObjectType': 'object',
                                                 'vipType': 'ignore',
                                                 'vipValue': '',
                                                 'vipVariableName': 'vpn_distance'},
                                    'ipv6-advertise': {'vipObjectType': 'tree',
                                                       'vipPrimaryKey': ['protocol'],
                                                       'vipType': 'ignore',
                                                       'vipValue': []}},
                            'route-export': {'vipObjectType': 'tree',
                                             'vipPrimaryKey': ['protocol'],
                                             'vipType': 'ignore',
                                             'vipValue': []},
                            'route-import': {'vipObjectType': 'tree',
                                             'vipPrimaryKey': ['protocol'],
                                             'vipType': 'ignore',
                                             'vipValue': []},
                            'route-import-service': {'from': {'vipObjectType': 'tree',
                                                              'vipPrimaryKey': ['vpn',
                                                                                'protocol'],
                                                              'vipType': 'ignore',
                                                              'vipValue': []}},
                            'service': {'vipObjectType': 'tree',
                                        'vipPrimaryKey': ['svc-type'],
                                        'vipType': 'ignore',
                                        'vipValue': []},
                            'tcp-optimization': {'vipObjectType': 'node-only',
                                                 'vipType': 'ignore',
                                                 'vipValue': 'false',
                                                 'vipVariableName': 'vpn_tcp_optimization'},
                            'vpn-id': {'vipObjectType': 'object',
                                       'vipType': 'constant',
                                       'vipValue': vpn_id}},
     'templateDescription': templateDescription,
     'templateMinVersion': '15.0.0',
     'templateName': templateName,
     'templateType': 'vpn-vedge'}
        )

def createVPNInterfacePayload(templateName, vpn_id, templateDescription=None, ifName=None, interfaceDescription=None):
    return json.dumps(\
        {'deviceType': ['vedge-cloud'],
         'factoryDefault': False,
         'templateDefinition': {'access-list': {'vipObjectType': 'tree',
                                                'vipPrimaryKey': ['direction'],
                                                'vipType': 'ignore',
                                                'vipValue': []},
                                'arp': {'ip': {'vipObjectType': 'tree',
                                               'vipPrimaryKey': ['addr'],
                                               'vipType': 'ignore',
                                               'vipValue': []}},
                                'arp-timeout': {'vipObjectType': 'object',
                                                'vipType': 'ignore',
                                                'vipValue': 1200,
                                                'vipVariableName': 'vpn_if_arp_timeout'},
                                'autonegotiate': {'vipObjectType': 'object',
                                                  'vipType': 'ignore',
                                                  'vipValue': 'true',
                                                  'vipVariableName': 'vpn_if_autonegotiate'},
                                'bandwidth-downstream': {'vipObjectType': 'object',
                                                         'vipType': 'ignore',
                                                         'vipVariableName': 'vpn_if_bandwidth_downstream'},
                                'bandwidth-upstream': {'vipObjectType': 'object',
                                                       'vipType': 'ignore',
                                                       'vipVariableName': 'vpn_if_bandwidth_upstream'},
                                'block-non-source-ip': {'vipObjectType': 'object',
                                                        'vipType': 'ignore',
                                                        'vipValue': 'false',
                                                        'vipVariableName': 'vpn_if_block_non_source_ip'},
                                'clear-dont-fragment': {'vipObjectType': 'object',
                                                        'vipType': 'ignore',
                                                        'vipValue': 'false',
                                                        'vipVariableName': 'vpn_if_clear_dont_fragment'},
                                'description': {'vipObjectType': 'object',
                                                'vipType': 'constant',
                                                'vipValue': interfaceDescription,
                                                'vipVariableName': 'vpn_if_description'},
                                'dhcp-helper': {'vipObjectType': 'list',
                                                'vipType': 'ignore',
                                                'vipVariableName': 'vpn_if_dhcp_helper'},
                                'dot1x': {'vipObjectType': 'node-only',
                                          'vipType': 'ignore'},
                                'duplex': {'vipObjectType': 'object',
                                           'vipType': 'ignore',
                                           'vipValue': '_empty',
                                           'vipVariableName': 'vpn_if_duplex'},
                                'flow-control': {'vipObjectType': 'object',
                                                 'vipType': 'ignore',
                                                 'vipValue': 'autoneg',
                                                 'vipVariableName': 'vpn_if_flow_control'},
                                'icmp-redirect-disable': {'vipObjectType': 'object',
                                                          'vipType': 'ignore',
                                                          'vipValue': 'false',
                                                          'vipVariableName': 'vpn_if_icmp_redirect_disable'},
                                'if-name': {'vipObjectType': 'object',
                                            'vipType': 'constant',
                                            'vipValue': ifName,
                                            'vipVariableName': 'vpn_if_name'},
                                'ip': {'address': {'vipObjectType': 'object',
                                                   'vipType': 'ignore',
                                                   'vipVariableName': 'vpn_if_ipv4_address'},
                                       'secondary-address': {'vipObjectType': 'tree',
                                                             'vipPrimaryKey': ['address'],
                                                             'vipType': 'ignore',
                                                             'vipValue': []}},
                                'ip-directed-broadcast': {'vipObjectType': 'object',
                                                          'vipType': 'ignore',
                                                          'vipValue': 'false',
                                                          'vipVariableName': 'vpn_if_ip-directed-broadcast'},
                                'ipv6': {'access-list': {'vipObjectType': 'tree',
                                                         'vipPrimaryKey': ['direction'],
                                                         'vipType': 'ignore',
                                                         'vipValue': []},
                                         'address': {'vipObjectType': 'object',
                                                     'vipType': 'ignore',
                                                     'vipValue': '',
                                                     'vipVariableName': 'vpn_if_ipv6_ipv6_address'},
                                         'dhcp-helper-v6': {'vipObjectType': 'tree',
                                                            'vipPrimaryKey': ['address'],
                                                            'vipType': 'ignore',
                                                            'vipValue': []},
                                         'ipv6-shutdown': {'vipObjectType': 'object',
                                                           'vipType': 'ignore',
                                                           'vipValue': 'false',
                                                           'vipVariableName': 'vpn_if_ipv6_ipv6_shutdown'},
                                         'secondary-address': {'vipObjectType': 'tree',
                                                               'vipPrimaryKey': ['address'],
                                                               'vipType': 'ignore',
                                                               'vipValue': []}},
                                'ipv6-vrrp': {'vipObjectType': 'tree',
                                              'vipPrimaryKey': ['grp-id'],
                                              'vipType': 'ignore',
                                              'vipValue': []},
                                'mac-address': {'vipObjectType': 'object',
                                                'vipType': 'ignore',
                                                'vipVariableName': 'vpn_if_mac_address'},
                                'mtu': {'vipObjectType': 'object',
                                        'vipType': 'ignore',
                                        'vipValue': 1500,
                                        'vipVariableName': 'vpn_if_ip_mtu'},
                                'pmtu': {'vipObjectType': 'object',
                                         'vipType': 'ignore',
                                         'vipValue': 'false',
                                         'vipVariableName': 'vpn_if_pmtu'},
                                'policer': {'vipObjectType': 'tree',
                                            'vipPrimaryKey': ['policer-name',
                                                              'direction'],
                                            'vipType': 'ignore',
                                            'vipValue': []},
                                'qos-map': {'vipObjectType': 'object',
                                            'vipType': 'ignore',
                                            'vipVariableName': 'qos_map'},
                                'rewrite-rule': {'rule-name': {'vipObjectType': 'object',
                                                               'vipType': 'ignore',
                                                               'vipVariableName': 'rewrite_rule_name'}},
                                'shaping-rate': {'vipObjectType': 'object',
                                                 'vipType': 'ignore',
                                                 'vipVariableName': 'qos_shaping_rate'},
                                'shutdown': {'vipObjectType': 'object',
                                             'vipType': 'ignore',
                                             'vipValue': 'true',
                                             'vipVariableName': 'vpn_if_shutdown'},
                                'speed': {'vipObjectType': 'object',
                                          'vipType': 'ignore',
                                          'vipValue': '_empty',
                                          'vipVariableName': 'vpn_if_speed'},
                                'static-ingress-qos': {'vipObjectType': 'object',
                                                       'vipType': 'ignore',
                                                       'vipVariableName': 'vpn_if_static_ingress_qos'},
                                'tcp-mss-adjust': {'vipObjectType': 'object',
                                                   'vipType': 'ignore',
                                                   'vipVariableName': 'vpn_if_tcp_mss_adjust'},
                                'tloc-extension': {'vipObjectType': 'object',
                                                   'vipType': 'ignore',
                                                   'vipVariableName': 'vpn_if_tloc_extension'},
                                'tloc-extension-gre-from': {'src-ip': {'vipObjectType': 'object',
                                                                       'vipType': 'ignore',
                                                                       'vipVariableName': 'vpn_if_tloc-ext_gre_from_src_ip'},
                                                            'xconnect': {'vipObjectType': 'object',
                                                                         'vipType': 'ignore',
                                                                         'vipVariableName': 'vpn_if_tloc-ext_gre_from_xconnect'}},
                                'tracker': {'vipObjectType': 'list',
                                            'vipType': 'ignore',
                                            'vipVariableName': 'vpn_if_tracker'},
                                'vrrp': {'vipObjectType': 'tree',
                                         'vipPrimaryKey': ['grp-id'],
                                         'vipType': 'ignore',
                                         'vipValue': []}},
         'templateDescription': templateDescription,
         'templateMinVersion': '15.0.0',
         'templateName': templateName,
         'templateType': 'vpn-vedge-interface'})


def main():
    wkGS = r"C:\00-Projects\00-WK\Firewall_rule_branch_v1.2.xlsx"
    c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345", gs="")
##    payload = createVPNPayload("VPN_500_Template", 500 ,"VPN_500_Template for Branch")
####    print(payload)

##    res = c90.post(api='/template/feature', payload=payload)
##    payload = createVPNInterfacePayload("FT_Global_BR_INTF_GE3.600_v1", 200, templateDescription="FT_Global_BR_INTF_GE3.600_v1 Template", ifName="GigabitEthernet3.600", interfaceDescription="GigabitEthernet3.600 Branch-III")
##    print(payload)
##    res = c90.post(api='/template/feature', payload=payload)
####    createVPNPayload(templateName, vpn_id, templateDescription=None):
    wb = fast_openpyxl(wkGS)
    createTemplates = wb[1]["sheet_createTemplate"]


    baseTemplate = "Base-Template-Site2"
    templates = c90.getDeviceTemplates()
    templates = transform(templates, 'templateName')
    for template in createTemplates:
        if baseTemplate in templates:
            tId = getID(templates, baseTemplate)
            api = f"/template/device/object/{tId}"
            res = c90.get(api=api)
            # print(res)
            pay = {
             "templateId":template['cisco_vpn'],
             "templateType":"cisco_vpn",
             "subTemplates":[
                {
                   "templateId":template["cisco_vpn_interface"],
                   "templateType":"cisco_vpn_interface"
                }
             ]
            }

            res["generalTemplates"].append(pay)
            res.pop('templateId')
            res['templateName'] = template["templateName"]
##            print(res)
            res = c90.post(api='/template/device/feature', payload= json.dumps(res))
            print(res)





##    print(templates)
    pass

if __name__ == '__main__':
    main()
