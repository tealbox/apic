#-------------------------------------------------------------------------------
# Author:       ashok.chauhan
# Version:      v1.5
#-------------------------------------------------------------------------------
## use module as below
### from sdwan_utils.utils import *
from ipaddress import ip_address
import re, os
from datetime import datetime
import json
from uuid import UUID
from pathlib import Path


def isValidIP(ipStr=None):
    if ipStr is None:
        return False
    if "/" in ipStr:
        # ip address also have netmask check number must be in range 1..32
        # slip and trim
        (ip,mask) = ipStr.split("/")
        try:
            ip = ip.strip() # remove white spaces from ip and mask
            mask = int(mask.strip())
##            print(mask)
            if 8 <= mask <= 32:
##                print(ip)
                ip_address(ip)
                return True
            else:
                return False
        except ValueError:
            return False
    try:
        ip_address(ipStr)
        return True
    except ValueError:
        return False

def checkIPStr(ipStr=None):
    if ipStr is None:
        return False
    if "," in ipStr:
        l = ipStr.split(",")
        for item in l:
            if not isValidIP(item):
                return False
        return True
    elif not isValidIP(ipStr): # could be a single IP
        return False
    else:
        return True

def ipPrefix(ipStr=None):
    if ipStr is None:
        return None
    if not checkIPStr(ipStr):
        return None
    else: # create list of ipPrefix
        prefixList = []
        l = ipStr.split(",")
        for item in l:
            prefixList.append( {"ipPrefix": item} )
        return prefixList

def dataPrefixPayload(name, desc=None, objType="dataprefix", ipStr=None):
    if ipStr is None:
        return None
    prefixList = ipPrefix(ipStr=ipStr)
    if prefixList is None:
        return None
    else:
        return { \
            "name":name,\
            "description":desc,\
            "type":"dataprefix",\
            "entries": prefixList
            }

def createListPayload(name, dtype, entries):
    return json.dumps({ \
        "name": name,\
        "type":dtype, \
        "entries":entries \
        })

def removeSpecialChar(s):
    pat = r"""\s|[\[\]\(\)\{\}})]"""
    s = re.sub(pat,'',s)
    return s

def classItemParse(item,dtype):
#     print(item['name'],item['entries_type'],item['entries_data'],)
    entriesList = []
    if item['entries'] != None and item['entries'] != "":
        entries_data = str(item.get('entries'))
        entries_data = removeSpecialChar(entries_data)
        if "," in entries_data:
            # split
            l =  [xItem.strip() for xItem in entries_data.split(',')]
            # [{"interface":"Loopback1"}]
            [entriesList.append({f"{dtype}":sitem}) for sitem in l]
        else:
            entriesList.append({f"{dtype}":entries_data})
    return entriesList


def transform(data, key):
    # data must be a list of dict
    if (not isinstance(data,(list,))) and len(data) == 0 and key not in data[0]:
        print("Data must be list of dict and atlead one item")
        return None
    temp = {}
    for item in data:
        temp.setdefault(item[key], item)
    return temp

def testUUID(tstUUID):
    from uuid import UUID
    try:
        _ = UUID(tstUUID)
    except ValueError:
        return False
    return True

def getID(data, key):
    # data must be dict
    if not isinstance(data, (dict,)):
        print("Data is not in json format")
        return None
    if key in data:
        # get a list of all
        keys = []
        [keys.append(k) for k in data[key].keys() if 'id' in k or 'Id' in k]
        # check which id having uuid value.
        for tkey in keys:
            if testUUID(data[key][tkey]):
                return data[key][tkey]

def getCSVPayload(templateId):
    return json.dumps({"templateId":templateId,"isEdited":False,"isMasterEdited":False} )




def removeSpecialChar(s):
    pat = r"""\s|[\[\]\(\)\{\}})]"""
    s = re.sub(pat,'',s)
    return s

def zoneItemParse(item):
#     print(item['name'],item['entries_type'],item['entries_data'],)
    interfaceList = []
    if item['entries_type'] != None and item['entries_type'] != "" and item['entries_data'] != None and item['entries_data'] != "":
        # check if entries_data is
        if item.get('entries_type', None).lower() == 'interface':
            # check if contain comma in entries_data then spilt
            if "," in item.get('entries_data', None):
                # split
                l = item.get('entries_data', None).split(",")
                # [{"interface":"Loopback1"}]
                for sitem in l:
                    interfaceList.append({"interface":sitem})
            else:
                interfaceList.append({"interface":item.get('entries_data', None)})
        elif item.get('entries_type', None).lower() == 'vpn':
            # converted to str for special case as Single entry will be integer
            entries_data = str(item.get('entries_data'))
            if "," in entries_data:
                # split
                l = entries_data.split(",")
                # [{"interface":"Loopback1"}]
                for sitem in l:
                    interfaceList.append({"vpn":sitem})
            else:
                interfaceList.append({"vpn":entries_data})
        else:
            print(f"item['entries_type']= Should not be interface or vpn")
    else:
        print(f"item['entries_type']= Should not be Blank")

    return interfaceList

def portItemParse(item,dtype):
#     print(item['name'],item['entries_type'],item['entries_data'],)
    entriesList = []
    if item['entries'] != None and item['entries'] != "":
        entries_data = str(item.get('entries'))
        entries_data = removeSpecialChar(entries_data)
        if "," in entries_data:
            # split
            l =  [xItem.strip() for xItem in entries_data.split(',')]
            # [{"interface":"Loopback1"}]
            [entriesList.append({f"{dtype}":sitem}) for sitem in l]
        else:
            entriesList.append({f"{dtype}":entries_data})
    return entriesList

def createListPayload(name, dtype, entries):
    return json.dumps({ \
        "name": name,\
        "type":dtype, \
        "entries":entries \
        })


### Version 1.5
def getvManageIP(configFile=None):
    # os & pathlib modules are required
    if not configFile:
        _ = Path(".")
        configFile = _ / "vManage.ini"
    # read file and ignore # lines
    configFile =  Path(configFile)
    with open(configFile, "r") as f:
        lines = f.readlines()
    for line in lines:
        if "#" in line and "\n" in line:
            continue
        if "vManage" in line:
            if "=" in line:
                l = line.split("=")
                if len(l) < 2:
                    print("Invalid format in vManage.ini file, should be vManage=10.10.20.90")
                    print("Correct and rerun")
                    raise SystemExit()
                else:
                    ip = l[1]
                    # check for valid IP
                    if isValidIP(ip):
                        return ip
            else:
                print("Invalid format in vManage.ini file, should be vManage=10.10.20.90")
                print("Correct and rerun")
                raise SystemExit()

