import os
import click


class Repo(object):
    def __init__(self, home=None, debug=False):
        self.home = os.path.abspath(home or '.')
        self.debug = debug
        print("Initializing Repo Object")

    def sayHello(self, name):
        print("Repo Object: ", name='Python')



@click.group()
@click.option('--repo-home', envvar='REPO_HOME', default='.repo')
@click.option('--debug/--no-debug', default=False,
              envvar='REPO_DEBUG')
@click.pass_context
def cli(ctx, repo_home, debug):
    ctx.obj = Repo(repo_home, debug)

@cli.command()
@click.argument('src')
@click.argument('dest', required=False)
@click.pass_obj
def clone(repo, src, dest):
    pass

@cli.command()
@click.option("--name", "-n", default="DEFAULT-REPO")
@click.pass_obj
def sayHello(repo, name):
    repo.sayHello
    pass



if __name__ == '__main__':
    cli()

