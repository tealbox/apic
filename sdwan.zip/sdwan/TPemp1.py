class First(object):
    def __init__(self, fname, **kw):
        super(First, self).__init__(**kw)
        self.fname = fname
        print("first ", self.fname)

class Second(object):
    def __init__(self, lname, **kw):
        super(Second, self).__init__(**kw)
        self.lname = lname
        print("second ", self.lname)

class Third(First, Second):
    def __init__(self, mname, **kw):
        super(Third, self).__init__(**kw)
        self.mname = mname
        print("Third ", self.mname)
    pass

Third(fname="AShok", lname="Chauhan", mname="Kumar")

##
##class First(object):
##    def __init__(self):
##        super(First, self).__init__()
##        print("first ")
##
##class Second(object):
##    def __init__(self):
##        super(Second, self).__init__()
##        print("second ")
##
##class Third(First, Second):
##    def __init__(self):
##        super(Third, self).__init__()
##        print("third")
##
##Third()