#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
import click, py, json

class Config(dict):
    def __init__(self, *args, **kwargs):
        self.config = py.path.local(
            click.get_app_dir('c3') # put app name
        ).join('config.json') # A

        super(Config, self).__init__(*args, **kwargs)

    def load(self):
        """load a JSON config file from disk"""
        try:
            self.update(json.loads(self.config.read())) # B
        except py.error.ENOENT:
            pass

    def save(self):
        self.config.ensure()
        with self.config.open('w') as f: # B
            f.write(json.dumps(self))

pass_config = click.make_pass_decorator(Config, ensure=True)

@click.group()
@pass_config
def cli(config):
    config.load()

@cli.command()
@pass_config
def say_hello(config):
    """say hello to someone"""
    click.echo("Hello, %s" % config.get("name", "unnamed entity"))

@cli.command()
@click.argument('name')
@pass_config
def my_name_is(config, name):
    """set the name to say hello to"""
    config['name'] = name
    config.save()
    click.echo("Set name")


if __name__ == '__main__':
    cli()