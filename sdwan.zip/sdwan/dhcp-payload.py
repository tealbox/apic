#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
import json
def dhcpPayload(templateName,templateDescription,templateType,deviceType,address_pool,exclude,default_gateway,dns_server ):
    return json.dumps( \
        {
          "templateName": templateName,
          "templateDescription": templateDescription,
          "templateType": "cisco_dhcp_server",
          "deviceType": [
            "vedge-C8000V"
          ],
          "templateMinVersion": "15.0.0",
          "templateDefinition": {
            "address-pool": {
              "vipObjectType": "object",
              "vipType": "constant",
              "vipValue": address_pool,
              "vipVariableName": "dhcp_address_pool"
            },
            "exclude": {
              "vipObjectType": "list",
              "vipType": "ignore",
              "vipVariableName": "dhcp-address_exclude"
            },
            "options": {
                "default-gateway": {
                "vipObjectType": "object",
                "vipType": "constant",
                "vipValue": default_gateway,
                "vipVariableName": "dhcp_default_gateway"
              },
              "dns-servers": {
                "vipObjectType": "list",
                "vipType": "constant",
                "vipValue": dns_server,
                "vipVariableName": "dhcp_dns_server"
              }
            }
          },
          "factoryDefault": False
        })


def main():
    print(dhcpPayload("GE3.400_DHCP","GE3.400 Wifi Printer & Printer","cisco_dhcp_server","vedge-C8000V", "192.168.100.100/24", "192.168.100.150", "192.168.100.254", [ "192.168.100.254", "192.168.100.201" ]))
    pass

if __name__ == '__main__':
    main()
