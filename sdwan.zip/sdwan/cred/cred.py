#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
import os, sys
from cryptography.fernet import Fernet
from getpass import getpass
from pathlib import Path
def write_key(keyfile): # used to create a key only required once so use it on-demand
    key = Fernet.generate_key() # Generates the key
    # remove exiting config file as well.
    _ = Path(".")
    configFile = _ / "cred.ini"
    os.remove(configFile)
    with open(keyfile, "wb") as key_file: # Opens the file the key is to be written to
        key_file.write(key) # Writes the key

def load_key(keyfile):
    return open(keyfile, "rb").read() #Opens the file, reads and returns the key stored in the file

def writeSNMPString(keyfile=None, configFile=None):
    if not configFile:
        _ = Path(".")
        configFile = _ / "cred.ini"
    if not keyfile:
        _ = Path("cred")
        keyfile = _ / "cutover.key"
    if not  os.path.exists(keyfile):
        print("keyfile file %s Not found" % keyfile)
        write_key(keyfile)
##        sys.exit(255)
    # if file exist do not override, remove file and run again
    # configFile = b"cred.ini"
    if os.path.exists(configFile):
        print("Config file %s already found reading it: " % configFile)
        return readSNMPString(configFile=configFile, keyfile=keyfile)

    snmpString = getpass(prompt="Cred: ").encode() # Takes the message as user input and encodes it
    key = load_key(keyfile) # Loads the key and stores it in a variable
    f = Fernet(key)
    encryptedSnmpString = f.encrypt(snmpString)
    with open(configFile, "wb") as configFile: # Opens the file the key is to be written to
        configFile.write(encryptedSnmpString) # Writes the key

def readSNMPString(configFile=None, keyfile=None):
    if not keyfile:
        _ = Path("cred")
        keyfile = _ / "cutover.key"
    if not configFile:
        _ = Path(".")
        configFile = _ / "cred.ini"

    if not  os.path.exists(keyfile):
        print("keyfile file %s Not found" % keyfile)
        sys.exit(255)
    if not  os.path.exists(configFile):
        print("Config file %s Not found" % configFile)
        sys.exit(255)
    with open(configFile) as cf:
        lines = cf.readlines()
##        print(lines)
        key = load_key(keyfile)
        f = Fernet(key)
        decrypted_message = f.decrypt(lines[0].encode())
        return decrypted_message.decode(encoding='utf-8')
    pass

