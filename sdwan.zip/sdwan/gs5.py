#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan import *
from myXLS import *
from sdwan_utils.utils import *
wkGS = r"C:\00-Projects\00-WK\Firewall_rule_branch_v1.2.xlsx"
import functools
import time, json


c90 = mySDWAN(vManage="192.168.86.27", username = "admin", passcode="VMware1!", gs="")
def prefixItemParse(item,dtype):
#     print(item['name'],item['entries_type'],item['entries_data'],)
    entriesList = []
    if item['entries'] != None and item['entries'] != "":
        entries_data = str(item.get('entries'))
        entries_data = removeSpecialChar(entries_data)
        if "," in entries_data:
            # split
            l =  [xItem.strip().lower() for xItem in entries_data.split(',')]
            # [{"interface":"Loopback1"}]
            for prefixItem in l:
                if 'le' in prefixItem:
                    pandlen = prefixItem.split(sep='le')
                    # {'ipPrefix': '10.10.4.0/23', 'le': '32'}
                    # check also for length if must be in range Future development
                    entriesList.append({f"{dtype}":pandlen[0], 'le': f"{pandlen[-1]}"})
                elif 'ge' in prefixItem:
                    # {'ipPrefix': '10.10.4.0/23', 'ge': '32'}
                    pandlen = prefixItem.split(sep='ge')
                    entriesList.append({f"{dtype}":pandlen[0], 'ge': f"{pandlen[-1]}"})
                else:
                    entriesList.append({f"{dtype}":prefixItem})
        else: # if entery dones not contain comma then default to add
            entriesList.append({f"{dtype}":entries_data})
    return entriesList

wb = fast_openpyxl(wkGS)
prefix = wb[1]["sheet_Prefix"]


for item in prefix:
    entries = prefixItemParse(item,'ipPrefix')
##    print(item)
    payload = createListPayload(item['name'], 'prefix', entries)
    print(payload)
    t = c90.post(api='/template/policy/list/prefix', method="POST", payload=payload)
def main():
    pass

if __name__ == '__main__':
    main()
